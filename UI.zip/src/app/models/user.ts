export class User {
  userId: any;
  accessToken : string;
}
